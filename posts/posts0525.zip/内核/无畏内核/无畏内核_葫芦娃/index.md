---
title: "无畏契约内核 葫芦娃公益内核"
date: 2026-04-09
draft: false
description: ""
tags: ["无畏契约", "无畏契约", "需要root", "内核"]
categories: ["内核", "需要root"]
---
### 更新日志

- 适配无畏契约新赛季
- 目前用的坐标只有人物靠近了才会显示，过迷雾全图坐标得等晚点重新找一下

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)

