---
title: "和平精英内核 橘子公益追锁内核"
# @Orangeflee
date: 2026-05-23
draft: false
description: ""
tags: ["和平精英", "和平精英内核", "需要root", "内核"]
categories: ["内核", "需要root"] 
---

### 卡密：

- 频道@Orangeflee

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)