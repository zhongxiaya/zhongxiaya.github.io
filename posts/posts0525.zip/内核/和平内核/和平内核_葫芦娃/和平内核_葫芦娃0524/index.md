---
title: "和平精英内核 葫芦娃公益内核辅助"
date: 2026-05-24
draft: false
description: ""
tags: ["和平精英", "和平精英内核", "需要root", "内核"]
categories: ["内核", "需要root"] 

---

### 更新日志

- 更新日志
- 新增突击兵密钥显示
- 新增侦察兵密钥显示
- 新增指挥官密钥显示



- 目前葫芦娃已适配
- 🎮PUBG，和平精英🎮，无畏契约🎮三游戏


### 预览截图

![预览](https://f.pz.al/pzal/2026/04/08/e8237a908c8fd.jpg)

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)