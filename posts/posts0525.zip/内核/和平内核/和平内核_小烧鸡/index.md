---
title: "和平精英内核 小烧鸡公益内核"
date: 2026-05-22
draft: false
description: ""
tags: ["和平精英", "和平精英内核", "需要root", "内核"]
categories: ["内核", "需要root"] 


---

### 更新日志：

- 适配新赛季
- 修复和平解密数组3没效果
- 新赛季不是游戏版本更新，数据不会变，正常用就行，不用焦虑

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)