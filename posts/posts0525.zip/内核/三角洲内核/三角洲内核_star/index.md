---
title: "三角洲内核 star内核辅助"
date: 2026-05-24
draft: false
description: ""
tags: ["三角洲", "三角洲内核", "需要root", "内核"]
categories: ["三角洲","内核", "需要root"]




---

### 更新日志

- 当前追锁适配
- [0]  无畏契约(国服) 1.22.0
- [1]  无畏契约(体验服) 1.23.0
- [2]  三角洲(国服)  1.201.37112.74
- [3]  三角洲(台服)  1.203.37112.5401
- [4]  三角洲(国际服) 1.202.37112.5401

- 使用方法：随便找个地方执行即可注入


![image.png](https://i3.ipix.ink/yh/2026/05/24/dW07ND/YddOsP.png)

- 无任何过检测，请勿裸奔

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)