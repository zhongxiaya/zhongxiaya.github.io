---
title: "迷你枪战直装 小米公益直装辅助"
date: 2026-04-18
draft: false
description: ""
tags: ["迷你枪战", "迷你枪战直装", "直装"]
categories: ["和平精英", "直装"]

---

### 功能介绍：

- 独家过检测  流畅的绘制

- 独家预判自瞄  独家函数子追

- 下载安装直接登陆即可

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1rs9bvHp_j1waC0Rpix6jrA?pwd=8888)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpg3EJPv3BxqCiaOX3JMr1UA1?pwd=5sn4#)  
- [夸克网盘](https://pan.quark.cn/s/0d5bff839e6b)  
- [UC网盘](https://drive.uc.cn/s/7d9c821891534?public=1)  