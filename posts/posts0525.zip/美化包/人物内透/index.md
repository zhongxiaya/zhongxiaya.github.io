---
title: "和平美化 人物内透pak功能文件"
date: 2026-05-24
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]
---

## 功能特点：

- 1️⃣人物内透（红色、绿色）
- 2️⃣优化已知问题
- 😙注意：此文件仅支持安卓端

### 预览截图

![image.png](https://i3.ipix.ink/yh/2026/05/24/Fs3n3K/3yddgm.png)

### 下载地址

- [百度网盘](https://pan.baidu.com/s/5luv6oQDR9DWFLJwl4DNSeg?)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpfzPQMs2u0hAx_Fw9cuckUA1?pwd=n5ry#)  
- [夸克网盘](https://pan.quark.cn/s/5d0edaf653b5)  
- [UC网盘](https://drive.uc.cn/s/f967a54c4f5e4?public=1)    