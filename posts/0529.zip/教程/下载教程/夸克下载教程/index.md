---
title: "【夸克】文件下载教程"
date: 2026-05-29
draft: false
description: ""
tags: ["使用教程"]
categories: ["使用教程"]

---

### 工具

1. 「[夸克](https://yh.cloudpix.cn/s/6J8Yl5)」

2. 「[MT管理器](https://pan.mt2.cn/apk/26052685)」

   ---

   

### 步骤一

1.下载夸克后，点击文件链接，跳转至夸克

### 步骤二
2.跳转后，点击保存，选择需要下载的文件，勾选【右侧小圆点】点击下载，等待下载完成

![夸克 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/9b038e85b3ab944347993a5c736ff56e.gif)