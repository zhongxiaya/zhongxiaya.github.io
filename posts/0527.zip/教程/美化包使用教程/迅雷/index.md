---
title: "美化包使用教程"
date: 2025-01-01
draft: false
description: ""
tags: ["和平精英美化包", 和平精英","使用教程"]
categories: ["和平精英","美化包", "使用教程"]
---
### 工具
1. 「[迅雷浏览器](https://down.sandai.net/browser_android/xunlei_x_browser_0x30800001.apk)」
2. 「[MT管理器](https://pan.mt2.cn/apk/26052685)」
### 1.下载美化包
1. 复制下方美化包链接，粘贴至「[迅雷浏览器](https://down.sandai.net/browser_android/xunlei_x_browser_0x30800001.apk)」输入框
- {{< copy "https://pan.xunlei.com/s/VOpfzPQMs2u0hAx_Fw9cuckUA1?pwd=n5ry#" "点击复制" >}}
- ![1 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/8a5e50c702c5b47c41f7a972a8765bfb.gif)
---
2. 网址粘贴至输入框，访问并点击保存
- ![1 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/8a5e50c702c5b47c41f7a972a8765bfb.gif)
### 2.使用美化包
- 下载后打开MT管理器，左侧文件滑到最底部，再点击左上角图标，再点击“内部存储”
- 2.再点击右上角“”-搜索-搜索刚刚下载的文件名“美化包”
- 3.然后点击搜索到的美化包文件，进入压缩包.zip
- 4.pak文件就是我们的美化包

5.接着右侧文件滑到最底部
6.点击顶部“文件夹”
7.复制下方目录
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks//storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点我复制" >}}



