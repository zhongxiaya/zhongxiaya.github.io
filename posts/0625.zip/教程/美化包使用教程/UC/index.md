---
title: "【UC】和平精英_美化包使用教程"
date: 2025-01-01
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "使用教程"]
categories: ["和平精英","美化包", "使用教程"]

---

### 工具

1. 「[UC浏览器](https://yh.cloudpix.cn/s/nPwY7l)」

2. 「[MT管理器](https://pan.mt2.cn/apk/26052685)」

   ---

   

### 步骤一 下载美化包

1.复制下方美化包链接，粘贴至「[UC浏览器](https://yh.cloudpix.cn/s/nPwY7l)」输入框，访问并保存至网盘

{{< copy "https://drive.uc.cn/s/f967a54c4f5e4?public=1#/list/share" "点击复制" >}}

![UC1 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/ba9b7cab2d22ceb983dcd51a23fc7932.gif)

---

---

---



2.访问并点击保存后，随便选个美化包(选择日期最新的)，勾选【右侧小圆点】下载，等待下载完成

![UC2 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/3643301deea86d2dcecdf746693dcb00.gif)

---



### 步骤二 使用美化包 上

1.下载完成后打开MT管理器，点击左上角图标，再点击“内部存储”

2.再点击右上角“搜索”刚刚下载的文件名“美化包”

3.点击进入美化包文件，找到.pak文件

![3 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/66d8878f15732833268ff78a98d164a5.gif)

### 步骤三 使用美化包 下

1.复制下方目录
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks//storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点我复制" >}}

2.打开MT管理器，右边的文件滑到最底部，点击顶部路径栏
3.粘贴刚刚复制的目录并确认

4.长按左侧的所有.pak文件，解压并确认(每个文件都需要长按解压至右边)

5.登录和平精英，享受白嫖的最新枪械皮肤+红装服饰+传世武器美化包吧

![4 00_00_00-00_00_30.gif](https://image.uc.cn/s/wemedia/s/upload/2026/301f9ac35f90c1c8de9f3e50b8476229.gif)

---

### 教程结束，上号重新效果吧！！！



有什么不理解的，可以QQ联系我

