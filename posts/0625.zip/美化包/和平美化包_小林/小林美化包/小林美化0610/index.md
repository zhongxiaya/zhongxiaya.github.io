---
title: "和平精英美化包 小林至尊版V200修复和谐"
date: 2026-06-10
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---

## 功能特点

- 大厅完美火箭＋机甲
- 最新大运车＋投掷物手持特效＋燃烧瓶手持

### 预览截图

![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/8493f44242418a4c37716d1ba1200701.png)

![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/826c9f6375d216bafcde20008b69805a.png)
![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/e0db8efddc8cb2e51221d927589e7bea.png)
### 美化包导入路径
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点击复制" >}}
### 下载地址
[6月10日测试可用】和平美化包_小林至尊版V200修复和谐](https://drive.uc.cn/s/68f4e6ac4f124) 

{{< copy "https://drive.uc.cn/s/68f4e6ac4f124" "点击复制链接" >}}

[UC下载教程](../UC)