---
title: "和平精英美化包 小林至尊版V204修复和谐(6.15最新美化)"
date: 2026-06-20
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---
![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/8493f44242418a4c37716d1ba1200701.png)
![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/826c9f6375d216bafcde20008b69805a.png)
![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/e0db8efddc8cb2e51221d927589e7bea.png)
### 功能特点：

- 大厅完美火箭＋机甲
### 美化包导入路径：
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点击复制" >}}
### 下载地址：
{{< download "https://pan.xunlei.com/s/VOv_b5yeeFiSg6XtJ6uwAQi1A1?pwd=siuw#" "点击下载" >}}