---
title: "和平精英美化包 小林至尊版V204修复和谐(6.15最新美化)"
date: 2026-06-15
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---
![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/8493f44242418a4c37716d1ba1200701.png)
![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/826c9f6375d216bafcde20008b69805a.png)
![手持传世武器预览](https://image.uc.cn/s/wemedia/s/upload/2026/e0db8efddc8cb2e51221d927589e7bea.png)
## 功能特点

- 大厅完美火箭＋机甲
- 最新大运车＋投掷物手持特效＋燃烧瓶手持
### 美化包导入路径
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点击复制" >}}
### 下载地址
{{< download "https://drive.uc.cn/s/19330c7a49974?public=1" "点击下载" >}}

[UC下载教程](../UC)