---
title: "和平精英美化包 小林至尊版V192(大厅机甲+大运车＋投掷物手持)"
date: 2026-05-23
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---

## 功能特点

- ✅经典无配件＋星际m4
- 😀投掷物手持特效＋燃烧瓶手持
- 👉直接搭配新的5.18原版 

### 预览截图

![手持传世武器预览](https://f.pz.al/pzal/2026/04/08/8206d986c7b1c.jpg)
![手持传世武器预览](https://f.pz.al/pzal/2026/04/08/5064c6e5800c2.jpg)

### 下载地址

- [百度网盘](https://pan.baidu.com/s/5luv6oQDR9DWFLJwl4DNSeg?)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpfzPQMs2u0hAx_Fw9cuckUA1?pwd=n5ry#)  