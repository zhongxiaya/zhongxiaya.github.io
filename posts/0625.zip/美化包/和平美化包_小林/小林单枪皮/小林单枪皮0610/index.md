---
title: "和平精英美化包 小林单枪皮单木乃伊V9(地铁原皮改轩辕Aug系列)"
date: 2026-06-10
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---

### 美化包导入路径
{{< copy "/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/" "点击复制" >}}
### 下载地址
[6月10日测试可用】和平美化包_小林单枪皮单木乃伊V9(地铁原皮改轩辕Aug系列)](https://drive.uc.cn/s/d83314b32ad84) 

{{< copy "https://drive.uc.cn/s/d83314b32ad84" "点击复制链接" >}}

[UC下载教程](../UC)