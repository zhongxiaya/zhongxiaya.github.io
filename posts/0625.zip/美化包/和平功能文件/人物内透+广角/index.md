---
title: "和平精英美化包 人物紫色内透+腰射/开镜广角pak功能文件"
date: 2026-05-23
draft: false
description: ""
tags: ["和平精英美化包", "和平精英", "免root"]
categories: ["美化包", "免root"]

---

## 功能特点：

- 1️⃣人物内透（紫色）
- 2️⃣人物腰射/开镜广角
- 3️⃣支持新赛季

### 预览截图

![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/48a9c0d19f9ed5f6611c992fb55018bc.png)

### 下载地址

- [百度网盘](https://pan.baidu.com/s/5luv6oQDR9DWFLJwl4DNSeg?)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpfzPQMs2u0hAx_Fw9cuckUA1?pwd=n5ry#)  
- [夸克网盘](https://pan.quark.cn/s/5d0edaf653b5)  
- [UC网盘](https://drive.uc.cn/s/f967a54c4f5e4?public=1)    