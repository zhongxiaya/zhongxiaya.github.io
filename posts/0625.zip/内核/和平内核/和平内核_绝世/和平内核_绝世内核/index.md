---
title: "和平精英内核 绝世公益高端内核"
# @fxnhnb
date: 2026-05-24
draft: false
description: ""
tags: ["和平精英", "和平精英内核", "需要root", "内核"]
categories: ["内核", "需要root"] 


---

### 卡密：

- 12345

### 更新日志

- 更新露哪打哪，指哪打哪，修复手雷没效果
- 🔥推荐使用的驱动是
- 《橘子驱动》一用一刷
- 《绝世KPM模块》
- 🔥推荐使用有模块陀螺仪



- ‼️使用新版本前删除旧版本配置文件/data/adb/FX配置

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)
- [迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)
- [夸克网盘](https://pan.quark.cn/s/cb14823989e9)
- [UC网盘](https://drive.uc.cn/s/c84b8d742d174?public=1)