---
title: "和平精英内核 快斗秒刷美化内核"
# @KIDMH66
date: 2026-06-10
draft: false
description: ""
tags: ["和平精英", "和平精英内核", "需要root", "内核"]
categories: ["内核", "需要root"] 

---

### 更新日志：
1.修复背包枪械无皮肤图标

2.修复美化的动作无音效

公益卡密：KIDMH66

### 下载地址：
[6月10日测试可用】和平内核_快斗和平美化.zip](https://drive.uc.cn/s/8eca784096ff4)

[UC浏览器下载教程](../UC浏览器下载教程)