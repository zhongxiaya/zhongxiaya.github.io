---
title: "lolm内核 于山内透"
date: 2026-06-02
draft: false
description: ""
tags: ["lolm", "lolm内核", "需要root", "内核"]
categories: ["内核", "需要root"]
---

### 卡密：
于山123


### 下载地址
[6月10日测试可用】lolm内核_于山内透.zip](https://drive.uc.cn/s/09cf1dcd04004)  