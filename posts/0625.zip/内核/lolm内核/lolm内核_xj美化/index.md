---
title: "lolm内核 小杰美化内核"
date: 2026-06-20
draft: false
description: ""
tags: ["lolm", "lolm内核", "需要root", "内核"]
categories: ["内核", "需要root"]
---
![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/ef7b95370b7b49a520a3dd7c0c313bb1.png)
### 使用教程：
MT管理器 root执行后，上游戏即可

英雄联盟手游（LOL手游英雄皮肤模型与特效，实现全英雄特效自由

### 下载地址
[6月10日测试可用】lolm内核_于山内透.zip](https://drive.uc.cn/s/09cf1dcd04004)  