---
title: "PUBG内核 RUN四服更新"
date: 2026-06-07
draft: false
description: ""
tags: ["PUBG", "PUBG内核", "需要root", "内核"]
categories: ["内核", "需要root"]
---
### 更新日志
1.更新了路飞功能

2.更新了趴下高跳，部分设备可以正常使用

3.添加了模型漏打(4服)

4.增加了模型绘制(4服)

5.稍微优化了一下UI的颜色和样子

6.优化了CPU的占用

### 下载地址
[【06月07日测试可用】PUBG内核_RUN内核_.zip ](https://drive.uc.cn/s/ca9dec85ea124)  

[UC网盘下载教程](../UC浏览器下载教程)