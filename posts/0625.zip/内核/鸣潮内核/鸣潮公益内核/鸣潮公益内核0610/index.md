---
title: "三角洲内核 鸣潮公益内核"
date: 2026-06-10
draft: false
description: ""
tags: ["鸣潮", "鸣潮内核", "需要root", "内核"]
categories: ["鸣潮","内核", "需要root"]
---

### 更新日志
适配最新3.4版本

### 下载地址
[6月10日测试可用】鸣潮内核_公益内核.zip](https://drive.uc.cn/s/ea57f7920b754)