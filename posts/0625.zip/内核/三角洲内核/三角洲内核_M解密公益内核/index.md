---
title: "三角洲内核 M解密公益内核"
date: 2026-05-29
draft: false
description: ""
tags: ["三角洲", "三角洲内核", "需要root", "内核"]
categories: ["三角洲","内核", "需要root"]



---

### 更新日志

- 史诗级大更新：
- 1.全面更换UI 支持cpu与gpu自选 (前提是你得用驱动模式)
- 2.更新陀螺仪自瞄 
- 3.子追叠戴为裸奔范围
- 适配全系 内置两款驱动 与 纯c模式 全机型都能玩
- 更新裸奔解密
- 6.解密无视物资加密 全局可透

### 下载地址

[【百度网盘】](https://pan.baidu.com/s/1cN0IpudxsXsscR5kAvrHDQ?pwd=8888)

[百度网盘下载教程](../百度网盘下载教程)

---

[迅雷网盘](https://pan.xunlei.com/s/VOpfyyN0tvULfjpoL9vVl9zBA1?pwd=9kmm#)

[迅雷网盘下载教程](../迅雷下载教程)

---

[夸克网盘](https://pan.quark.cn/s/cb14823989e9)

[夸克网盘下载教程](../夸克下载教程)

---

[UC浏览器](https://drive.uc.cn/s/c84b8d742d174?public=1)

[UC浏览器下载教程](../UC浏览器下载教程)