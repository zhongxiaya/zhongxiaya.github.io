---
title: "火影忍者内核 马骝仔公益内核"
date: 2026-06-09
draft: false
description: ""
tags: ["火影忍者", "火影忍者内核", "需要root", "内核"]
categories: ["火影忍者","内核", "需要root"]
---


### 下载地址
[6月10日测试可用】火影忍者内核_马骝仔公益内核.zip](https://drive.uc.cn/s/45945002d0f54)