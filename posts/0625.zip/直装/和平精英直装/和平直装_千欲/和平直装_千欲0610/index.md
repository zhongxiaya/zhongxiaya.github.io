---
title: "和平精英直装 千欲追锁漏打直装v12"
date: 2026-06-10
draft: false
description: ""
tags: ["和平精英", "和平精英直装", "直装"]
categories: ["和平精英", "直装"]
---


![image.png](https://i3.ipix.ink/yh/2026/05/24/YAFrPv/yzW68O.png)

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1rs9bvHp_j1waC0Rpix6jrA?pwd=8888)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpg3EJPv3BxqCiaOX3JMr1UA1?pwd=5sn4#)  
- [夸克网盘](https://pan.quark.cn/s/0d5bff839e6b)  
- [UC网盘](https://drive.uc.cn/s/7d9c821891534?public=1)  