---
title: "和平精英直装 由崎司直装容器"
date: 2026-05-25
draft: false
description: ""
tags: ["和平精英", "和平精英直装", "直装"]
categories: ["和平精英", "直装"]


---

### 公益卡密：

- YQSMOD



### 更新日志：

- ![image.png](https://image.uc.cn/s/wemedia/s/upload/2026/525a54301c4d4d74780121c3cbdcfcba.png)
- 更新内容: 内测已完毕无任何禁令正式上市添加了防录屏拥有美化以及娱乐功能目前为公益状态
- 注意不要打太猛否则容易进巡查下线追封演戏决定你能稳多久--

- 如果出现小黑屋=行为/吃举报，冻结账号=吃太多举报，这些都是正常的是因为自己不演戏导致的你的演技决定你的稳定性

- 危险功能基本都是一开就秒封号，仅娱乐使用开了封了不要来怪我--

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1rs9bvHp_j1waC0Rpix6jrA?pwd=8888)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpg3EJPv3BxqCiaOX3JMr1UA1?pwd=5sn4#)  
- [夸克网盘](https://pan.quark.cn/s/0d5bff839e6b)  
- [UC网盘](https://drive.uc.cn/s/7d9c821891534?public=1)  