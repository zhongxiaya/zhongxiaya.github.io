---
title: "PUBG直装 残羽一体直装"
date: 2026-05-25
draft: false
description: ""
tags: ["PUBG", "PUBG直装", "直装"]
categories: ["PUBG", "直装"]



---

### 公益卡密：

@CY_MODS



### 更新日志：

- 流畅的绘制
- 仿触摸自瞄
- 概率追踪
- 忽略人机 忽略倒地
- 秒刷新美化
- 稳定旁路

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1rs9bvHp_j1waC0Rpix6jrA?pwd=8888)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpg3EJPv3BxqCiaOX3JMr1UA1?pwd=5sn4#)  
- [夸克网盘](https://pan.quark.cn/s/0d5bff839e6b)  
- [UC网盘](https://drive.uc.cn/s/7d9c821891534?public=1)  