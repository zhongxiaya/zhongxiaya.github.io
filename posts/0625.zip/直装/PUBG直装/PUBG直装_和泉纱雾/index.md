---
title: "PUBG直装 和泉纱雾容器直装"
date: 2026-05-25
draft: false
description: ""
tags: ["PUBG", "PUBG直装", "直装"]
categories: ["PUBG", "直装"]



---

### 公益卡密：

和泉纱雾一体直装@HQSWMOD



### 更新日志：

- ➡️修复已知禁令问题
- ➡️修复全球端开枪禁网
- ➡️修复全球端追一天
- ➡️修复部分设备卡屏
- ➡️取消进入动画

### 下载地址

- [百度网盘](https://pan.baidu.com/s/1rs9bvHp_j1waC0Rpix6jrA?pwd=8888)  
- [迅雷网盘](https://pan.xunlei.com/s/VOpg3EJPv3BxqCiaOX3JMr1UA1?pwd=5sn4#)  
- [夸克网盘](https://pan.quark.cn/s/0d5bff839e6b)  
- [UC网盘](https://drive.uc.cn/s/7d9c821891534?public=1)  